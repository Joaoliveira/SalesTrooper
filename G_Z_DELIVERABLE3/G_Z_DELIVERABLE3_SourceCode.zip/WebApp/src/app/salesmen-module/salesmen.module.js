(function() {
    'use strict';

    angular
        .module('salesmen-module', [
        ]);
})();