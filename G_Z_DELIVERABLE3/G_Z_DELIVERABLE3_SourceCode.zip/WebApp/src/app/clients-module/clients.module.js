(function() {
    'use strict';

    angular
        .module('clients-module', [
        ]);
})();