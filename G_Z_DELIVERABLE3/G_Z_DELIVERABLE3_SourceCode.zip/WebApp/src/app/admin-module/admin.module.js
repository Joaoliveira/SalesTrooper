(function() {
    'use strict';

    angular
        .module('admin-module', [
        ]);
})();