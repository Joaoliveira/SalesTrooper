(function() {
    'use strict';

    angular
        .module('dashboard-module', [
        ]);
})();