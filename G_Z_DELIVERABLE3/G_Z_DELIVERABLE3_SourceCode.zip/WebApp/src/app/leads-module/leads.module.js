(function() {
    'use strict';

    angular
        .module('leads-module', [
        ]);
})();