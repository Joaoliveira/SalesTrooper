﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FirstREST.Lib_Primavera.Model
{
    public class Vendedor
    {
        public string CodVendedor
        {
            get;
            set;
        }

        public string NomeVendedor
        {
            get;
            set;
        }
    }
}